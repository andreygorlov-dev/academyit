package exercise1;

/**
 * Вывести на экран текст «Silence is golden». Каждое слово должно быть на
 * новой строке.
 */
public class Task1 {

    public static void main(String[] args) {
        System.out.println("Silence\nis\ngolden");
    }

}
