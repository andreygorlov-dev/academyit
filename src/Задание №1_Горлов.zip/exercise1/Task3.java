package exercise1;

/**
 * Дано расстояние в метрах. Найти число полных километров в нем.
 */
public class Task3 {

    public static void main(String[] args) {

        int distanceMeters = 120999;

        System.out.println("In " + distanceMeters + "(m) full kilometers " + distanceMeters / 1000);

    }

}
